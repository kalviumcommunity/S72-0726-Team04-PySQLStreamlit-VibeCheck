/**
 * Typed client for the VibeCheck Django API.
 *
 * The base URL comes from NEXT_PUBLIC_API_BASE_URL so the dashboard can point at
 * a deployed backend without a code change. See frontend/.env.local.example.
 */

export const API_BASE_URL = (
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://127.0.0.1:8000"
).replace(/\/+$/, "");

export interface KPIPayload {
  avg_onboarding_days: number;
  time_to_value: number;
  avg_tickets: number;
  new_hire_count: number;
}

export interface ScatterPoint {
  employee_id: number;
  training_completion_percent: number;
  ticket_count: number;
}

export interface BlockerRow {
  issue_type: string;
  count: number;
}

export interface BuddyImpactRow {
  buddy_assigned: string | boolean | number;
  training_completion_percent: number;
  employee_count: number;
}

export type ToolAdoptionRow = { date: string } & Record<string, string | number>;

export interface ChartsPayload {
  scatter: ScatterPoint[];
  blockers: BlockerRow[];
  tool_adoption: ToolAdoptionRow[];
  buddy_impact: BuddyImpactRow[];
}

export interface EmployeeFriction {
  employee_id: number;
  JobRole: string;
  Department: string;
  onboarding_status: string;
  training_completion_percent: number;
  ticket_count: number;
  avg_resolution: number;
  /** null when the ML model could not be loaded on the backend. */
  predicted_risk: number | null;
  friction_score: number;
}

export interface EmployeesPayload {
  /** Number of employees above the high-friction threshold across the WHOLE dataset. */
  total_high_risk: number;
  high_friction_threshold: number;
  /** True when the backend successfully loaded best_model.pkl. */
  ml_model_available: boolean;
  results: EmployeeFriction[];
}

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status?: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

async function getJSON<T>(path: string, signal?: AbortSignal): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${API_BASE_URL}${path}`, {
      signal,
      headers: { Accept: "application/json" },
      cache: "no-store",
    });
  } catch (cause) {
    if (cause instanceof DOMException && cause.name === "AbortError") throw cause;
    throw new ApiError(
      `Could not reach the VibeCheck API at ${API_BASE_URL}. Is the Django server running?`,
    );
  }

  if (!response.ok) {
    throw new ApiError(
      `The API returned ${response.status} ${response.statusText} for ${path}.`,
      response.status,
    );
  }

  return (await response.json()) as T;
}

export const fetchKPIs = (signal?: AbortSignal) =>
  getJSON<KPIPayload>("/api/kpis/", signal);

export const fetchCharts = (signal?: AbortSignal) =>
  getJSON<ChartsPayload>("/api/charts/", signal);

export const fetchEmployees = (signal?: AbortSignal) =>
  getJSON<EmployeesPayload>("/api/employees/", signal);
