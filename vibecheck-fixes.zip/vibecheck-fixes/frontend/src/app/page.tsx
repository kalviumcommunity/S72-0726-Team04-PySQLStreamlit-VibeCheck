"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ApiError,
  ChartsPayload,
  EmployeeFriction,
  EmployeesPayload,
  KPIPayload,
  fetchCharts,
  fetchEmployees,
  fetchKPIs,
} from "@/lib/api";
import AnimatedCard from "@/components/AnimatedCard";
import FrictionScatter from "@/components/charts/FrictionScatter";
import ToolAdoptionLine from "@/components/charts/ToolAdoptionLine";
import BlockersBarChart from "@/components/charts/BlockersBarChart";
import BuddyImpactChart from "@/components/charts/BuddyImpactChart";
import EmployeeCardGrid from "@/components/EmployeeCardGrid";
import EmployeeDrawer from "@/components/EmployeeDrawer";
import { Button } from "@/components/ui/button";
import { CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { AlertCircle, Info } from "lucide-react";

const ALL_DEPARTMENTS = "All Departments";

export default function Dashboard() {
  const [kpis, setKpis] = useState<KPIPayload | null>(null);
  const [charts, setCharts] = useState<ChartsPayload | null>(null);
  const [employeeData, setEmployeeData] = useState<EmployeesPayload | null>(null);
  const [selectedEmployee, setSelectedEmployee] = useState<number | null>(null);
  const [department, setDepartment] = useState<string>(ALL_DEPARTMENTS);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const load = useCallback((signal?: AbortSignal) => {
    if (!signal) {
      // Only a manual retry needs to reset the visible state; the initial
      // effect-driven load already starts in the loading state.
      setIsLoading(true);
      setError(null);
    }
    // Every request needs a rejection handler. Without one, a stopped Django
    // server left the dashboard spinning on "Loading insights..." forever.
    Promise.all([fetchKPIs(signal), fetchCharts(signal), fetchEmployees(signal)])
      .then(([k, c, e]) => {
        setKpis(k);
        setCharts(c);
        setEmployeeData(e);
      })
      .catch((cause: unknown) => {
        if (signal?.aborted) return;
        setError(
          cause instanceof ApiError
            ? cause.message
            : "Something went wrong loading the dashboard.",
        );
      })
      .finally(() => {
        if (!signal?.aborted) setIsLoading(false);
      });
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    // Kick the fetch off in a microtask so the effect body itself does not
    // synchronously call setState (react-hooks/set-state-in-effect).
    queueMicrotask(() => load(controller.signal));
    return () => controller.abort();
  }, [load]);

  const employees: EmployeeFriction[] = useMemo(
    () => employeeData?.results ?? [],
    [employeeData],
  );

  const departments = useMemo(() => {
    const names = new Set(employees.map((e) => e.Department).filter(Boolean));
    return [ALL_DEPARTMENTS, ...Array.from(names).sort()];
  }, [employees]);

  const visibleEmployees = useMemo(
    () =>
      department === ALL_DEPARTMENTS
        ? employees
        : employees.filter((e) => e.Department === department),
    [employees, department],
  );

  const threshold = employeeData?.high_friction_threshold ?? 40;

  // Only employees actually over the threshold belong in the intervention
  // grid. The previous version took the first six rows unconditionally, so it
  // labelled healthy hires "high-friction" whenever nobody was struggling.
  const highFrictionEmployees = useMemo(
    () => visibleEmployees.filter((e) => e.friction_score > threshold).slice(0, 6),
    [visibleEmployees, threshold],
  );

  // Counted by the API over the whole dataset, not just the returned page.
  const highRiskCount = employeeData?.total_high_risk ?? 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="animate-pulse flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-slate-300 border-t-slate-900 rounded-full animate-spin"></div>
          <p className="mt-4 text-slate-500 font-medium">Loading insights...</p>
        </div>
      </div>
    );
  }

  if (error || !kpis || !charts || !employeeData) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
        <div className="max-w-md w-full bg-white border border-red-200 rounded-2xl p-8 shadow-sm text-center">
          <AlertCircle className="w-10 h-10 text-red-600 mx-auto" />
          <h2 className="mt-4 text-xl font-bold text-slate-900">
            Couldn&apos;t load the dashboard
          </h2>
          <p className="mt-2 text-sm text-slate-600">
            {error ?? "The API returned an unexpected response."}
          </p>
          <Button className="mt-6" onClick={() => load()}>
            Try again
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 relative overflow-hidden p-8 text-slate-900 font-sans space-y-6 z-0">
      {/* Top Filter Bar */}
      <div className="flex items-center justify-between bg-white backdrop-blur-md border border-slate-200 p-5 rounded-2xl shadow-sm mb-8 transition-all hover:shadow-md">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            Onboarding Operations
          </h1>
          <p className="text-slate-500 mt-1">
            Friction and productivity analytics across {kpis.new_hire_count} new
            hires
          </p>
        </div>
        <div className="flex gap-3">
          <label className="sr-only" htmlFor="department-filter">
            Filter by department
          </label>
          <select
            id="department-filter"
            value={department}
            onChange={(event) => setDepartment(event.target.value)}
            className="bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:ring-2 focus:ring-slate-900 outline-none transition-all hover:border-slate-400 cursor-pointer"
          >
            {departments.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Dynamic Alert Banner */}
      {highRiskCount > 0 && (
        <div className="bg-red-50 border border-red-200 p-4 rounded-xl flex items-center gap-3 shadow-sm mb-6 backdrop-blur-sm animate-in fade-in slide-in-from-top-4 duration-500">
          <AlertCircle className="w-5 h-5 text-red-600 animate-pulse" />
          <span className="font-medium text-red-900">
            Action Required:{" "}
            <span className="font-bold">{highRiskCount} new hires</span> have a
            friction score over {threshold}.
          </span>
        </div>
      )}

      {!employeeData.ml_model_available && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl flex items-center gap-3 shadow-sm mb-6">
          <Info className="w-5 h-5 text-amber-600" />
          <span className="font-medium text-amber-900">
            The risk model could not be loaded, so ML risk scores are hidden.
            Check the backend logs and the ML model/ artefacts.
          </span>
        </div>
      )}

      {/* KPIs */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <AnimatedCard delay={0.1}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-500">
              Avg Onboarding Days
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{kpis.avg_onboarding_days}</div>
          </CardContent>
        </AnimatedCard>
        <AnimatedCard delay={0.2}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-500">
              Time-to-Value (Days)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{kpis.time_to_value}</div>
            <p className="text-xs text-slate-400 mt-1">
              Onboarding duration + 7-day ramp-up assumption
            </p>
          </CardContent>
        </AnimatedCard>
        <AnimatedCard delay={0.3}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-500">
              Avg Tickets per New Hire
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{kpis.avg_tickets}</div>
          </CardContent>
        </AnimatedCard>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <AnimatedCard delay={0.4}>
          <CardHeader className="pb-2 border-b border-slate-100">
            <CardTitle className="text-base font-semibold text-slate-800">
              Tickets by Training Cohort
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <FrictionScatter data={charts.scatter} />
          </CardContent>
        </AnimatedCard>

        <AnimatedCard delay={0.5}>
          <CardHeader>
            <CardTitle>Tool Adoption Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ToolAdoptionLine data={charts.tool_adoption} />
          </CardContent>
        </AnimatedCard>

        <AnimatedCard delay={0.6}>
          <CardHeader>
            <CardTitle>Top IT Bottlenecks</CardTitle>
          </CardHeader>
          <CardContent>
            <BlockersBarChart data={charts.blockers} />
          </CardContent>
        </AnimatedCard>

        <AnimatedCard delay={0.7}>
          <CardHeader>
            <CardTitle>Buddy Impact on Training %</CardTitle>
          </CardHeader>
          <CardContent>
            <BuddyImpactChart data={charts.buddy_impact} />
          </CardContent>
        </AnimatedCard>
      </div>

      {/* High Friction Employee Cards */}
      <AnimatedCard delay={0.8}>
        <CardHeader>
          <CardTitle>High-Friction Employees</CardTitle>
          <p className="text-sm text-slate-500">
            Employees scoring above {threshold} and needing intervention
          </p>
        </CardHeader>
        <CardContent>
          {highFrictionEmployees.length > 0 ? (
            <EmployeeCardGrid
              employees={highFrictionEmployees}
              onRowClick={setSelectedEmployee}
              showMlRisk={employeeData.ml_model_available}
            />
          ) : (
            <p className="text-sm text-slate-500 py-8 text-center">
              No employees are above the friction threshold
              {department !== ALL_DEPARTMENTS ? ` in ${department}` : ""}.
            </p>
          )}
        </CardContent>
      </AnimatedCard>

      <EmployeeDrawer
        employeeId={selectedEmployee}
        isOpen={selectedEmployee !== null}
        onClose={() => setSelectedEmployee(null)}
      />
    </div>
  );
}
