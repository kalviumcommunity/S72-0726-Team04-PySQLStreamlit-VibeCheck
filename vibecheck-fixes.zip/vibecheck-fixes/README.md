# VibeCheck: Operational Data & Onboarding Analytics

[![Next.js](https://img.shields.io/badge/Next.js-14-black?logo=next.js)](https://nextjs.org/)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB?logo=python)](https://python.org)
[![Django](https://img.shields.io/badge/Django-API-092E20?logo=django)](https://www.djangoproject.com/)
[![Supabase](https://img.shields.io/badge/Supabase-REST_API-3ECF8E?logo=supabase)](https://supabase.com)

## 📌 About the Project

**VibeCheck** is an interactive analytics dashboard designed to give leadership visibility into operational friction points that slow down new hire productivity during their first month. 

By combining HR demographics, onboarding checklists, support tickets, and daily tool usage, VibeCheck helps identify bottlenecks and highlights employees who are struggling (experiencing high "friction").

---

## 📈 Understanding the Dashboard & Metrics

### What is the "Friction Score"?
The **Friction Score** is a composite 0-100 metric indicating how difficult an employee's onboarding experience is. It blends three normalised signals so that no single unbounded input can dominate:

| Component | Weight | Normalisation |
| :--- | :--- | :--- |
| Outstanding training (`100 - training_completion_percent`) | 50% | already 0-100 |
| Support ticket volume | 30% | saturates at 5 tickets |
| Average ticket resolution time | 20% | saturates at 48 hours |

Because the weights sum to 1.0, the score is naturally bounded to 0-100 with no clipping.

- **> 40 — High.** Blocked, undertrained, or stuck behind IT issues. Needs intervention. In the bundled dataset this flags 17 people, every one of them a new hire.
- **25-40 — Medium.** Worth watching.
- **< 25 — Low.** Smooth onboarding.

Thresholds live in `backend/api/views.py` (`HIGH_FRICTION_THRESHOLD`, `MEDIUM_FRICTION_THRESHOLD`) and are returned by the API so the frontend never hard-codes them.

### What the Graphs Tell Us:
- **Tickets by Training Cohort (Bar Chart)**: Average support tickets raised by each training-completion band. Employees with lower training completion raise more tickets, indicating a clear operational bottleneck. (Rendered as bars rather than a scatter because 1,470 overlapping points were unreadable.)
- **Tool Adoption Over Time (Line Chart)**: Tracks how quickly new hires adopt and actively use internal tools (like Jira, GitHub, or Slack) over their first weeks.
- **Top IT Bottlenecks (Bar Chart)**: Highlights the most common types of support tickets raised by new hires (e.g., access requests, hardware issues), identifying areas where IT can proactively remove blockers.
- **Buddy Impact (Bar Chart)**: Compares training completion for employees with and without an assigned buddy. **Read with care:** in the bundled dataset the groups are 1,451 vs 19, so the gap is suggestive, not causal. The chart displays both group sizes for this reason.

### The ML risk score
Separately from the rule-based friction score, `ML model/best_model.pkl` predicts the probability that an employee ends up high-friction, using only *early* signals (first 14 days of tool activity plus HR attributes). Honest held-out performance is **ROC-AUC 0.66, accuracy 0.63** — better than chance, not a solved problem. Treat it as a triage aid, not a verdict. If the model or its feature table is missing, the API reports `ml_model_available: false` and the dashboard hides the risk badges rather than showing a fake 0%.

---

## 🚀 Quick Start Guide

### 1. Prerequisites
Ensure you have Python 3.10+ and Node.js 18+ installed on your system.

### 2. Environment Variables
Copy `.env.example` to `.env` in the project root and fill in what you need:
```bash
cp .env.example .env
```
Supabase credentials are optional — if `SUPABASE_URL` / `SUPABASE_ANON_KEY` are absent, the Django backend falls back to the CSV files in `data/` and logs that it did so. A misconfigured Supabase connection is logged too, rather than silently masquerading as a successful read.

`.env` is gitignored. Never commit real credentials.

### 3. Start the Backend (Django)
Open a terminal and run the following commands to start the API:
```bash
cd backend
python -m venv venv
.\venv\Scripts\activate      # macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

Run the test suite with:
```bash
python manage.py test api
```

### 4. Start the Frontend (Next.js)
Open a separate terminal and run the following commands to start the UI:
```bash
cd frontend
cp .env.local.example .env.local   # only if the API is not on 127.0.0.1:8000
npm install
npm run dev
```

Open your browser at `http://localhost:3000` to view the dashboard!

---

## 🛠️ Project Structure

```
S72-0726-Team04-PySQLStreamlit-VibeCheck/
├── .env                     # Environment variables for Supabase
├── backend/                 # Django DRF backend API
│   ├── api/                 # Django app processing Pandas/Supabase data
│   └── config/              # Django project settings
├── frontend/                # Next.js frontend application
│   ├── src/app/             # App router pages (dashboard layout)
│   ├── src/components/      # UI components and Recharts charts
│   └── src/lib/             # Typed API client (api.ts) and cn() helper (utils.ts)
├── ML model/                # Notebooks 01-06: EDA -> features -> training -> scoring
└── data/                    # Datasets (used as local fallback)
```

---

## 🔌 API Reference

All endpoints are read-only JSON, served from `http://127.0.0.1:8000`.

| Endpoint | Returns |
| :--- | :--- |
| `GET /api/kpis/` | `avg_onboarding_days`, `time_to_value`, `avg_tickets`, `new_hire_count`. Scoped to the new-hire cohort (`YearsAtCompany <= 1` **or** onboarding still In Progress/Delayed), not the whole company. |
| `GET /api/charts/` | `scatter`, `blockers`, `tool_adoption` (chronological), `buddy_impact` (with group sizes). |
| `GET /api/employees/` | `{ total_high_risk, high_friction_threshold, medium_friction_threshold, ml_model_available, results[] }`. Supports `?limit=` (default 100, max 1000) and `?department=`. `total_high_risk` is counted across the whole dataset, not just the returned page. |

---

## 🧠 Rebuilding the ML artefacts

Run the notebooks in `ML model/` in order (01 → 06). They resolve paths relative to the repo root, so the working directory does not matter. Notebook 04 saves `best_model.pkl` as a scikit-learn **Pipeline** (StandardScaler + classifier), so any consumer can call `predict_proba` on raw engineered features without remembering to scale first.
