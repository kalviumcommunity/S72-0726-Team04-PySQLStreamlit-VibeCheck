"""Data access helpers.

Reads each logical table from Supabase when credentials are configured, and
falls back to the CSV snapshots in ``data/`` otherwise. The fallback is logged
loudly so a misconfigured Supabase connection can never masquerade as a
successful remote read.
"""

import logging
import os
from pathlib import Path

import pandas as pd
from dotenv import load_dotenv

logger = logging.getLogger(__name__)

# backend/api/utils.py -> backend/api -> backend -> <project root>
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"

load_dotenv(PROJECT_ROOT / ".env")

SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_ANON_KEY")

KNOWN_TABLES = ("employees", "onboarding", "support_tickets", "tool_usage")


def supabase_configured() -> bool:
    return bool(SUPABASE_URL and SUPABASE_KEY)


def get_supabase_client():
    """Return a Supabase client, or raise if it is not usable.

    ``supabase`` is imported lazily so the API still starts (on CSV data) when
    the package is not installed.
    """
    if not supabase_configured():
        raise RuntimeError(
            "SUPABASE_URL / SUPABASE_ANON_KEY are not set; using local CSV data."
        )
    try:
        from supabase import create_client
    except ImportError as exc:  # pragma: no cover - depends on environment
        raise RuntimeError(
            "The 'supabase' package is not installed; using local CSV data."
        ) from exc
    return create_client(SUPABASE_URL, SUPABASE_KEY)


def read_local_csv(table_name: str) -> pd.DataFrame:
    """Read a table from the bundled CSV snapshot."""
    if table_name not in KNOWN_TABLES:
        raise ValueError(
            f"Unknown table {table_name!r}. Expected one of {KNOWN_TABLES}."
        )
    csv_path = DATA_DIR / f"{table_name}.csv"
    if not csv_path.exists():
        raise FileNotFoundError(
            f"Dataset {csv_path} is missing. Restore it from version control "
            f"or regenerate the datasets (see data/README.md)."
        )
    return pd.read_csv(csv_path)


def fetch_table_as_df(table_name: str) -> pd.DataFrame:
    """Fetch a table as a DataFrame, preferring Supabase and falling back to CSV.

    An empty Supabase response is treated as a failure rather than as an empty
    table, because downstream views index into columns by name.
    """
    if supabase_configured():
        try:
            client = get_supabase_client()
            response = client.table(table_name).select("*").execute()
            rows = getattr(response, "data", None) or []
            if rows:
                return pd.DataFrame(rows)
            logger.warning(
                "Supabase returned no rows for table %r; falling back to CSV.",
                table_name,
            )
        except Exception:
            logger.warning(
                "Supabase read failed for table %r; falling back to CSV.",
                table_name,
                exc_info=True,
            )
    return read_local_csv(table_name)


def yes_no_to_bool(series: pd.Series) -> pd.Series:
    """Normalise the Yes/No/true/1 flags used across the onboarding dataset."""
    return (
        series.astype(str)
        .str.strip()
        .str.lower()
        .isin({"yes", "y", "true", "1"})
    )
