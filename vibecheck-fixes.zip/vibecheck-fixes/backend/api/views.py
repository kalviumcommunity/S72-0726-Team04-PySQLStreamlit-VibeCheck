"""Dashboard API endpoints.

Three read-only endpoints back the Next.js dashboard:

* ``/api/kpis/``      headline numbers for the KPI row
* ``/api/charts/``    aggregated series for the four charts
* ``/api/employees/`` the ranked high-friction employee list
"""

import logging
import pickle
from functools import lru_cache
from pathlib import Path

import pandas as pd
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from .utils import PROJECT_ROOT, fetch_table_as_df, yes_no_to_bool

logger = logging.getLogger(__name__)

ML_DIR = PROJECT_ROOT / "ML model"
MODEL_PATH = ML_DIR / "best_model.pkl"
ENGINEERED_DATA_PATH = ML_DIR / "engineered_data.csv"

# Intervention thresholds, calibrated against the observed score distribution
# (median 8.5, p90 23.5, max 62.2). The old value of 70 was inherited from the
# unbounded score that clipped everyone to 100; on the corrected scale nothing
# ever crossed it, so the alert banner could never fire. At 40, the flagged set
# is 17 employees - every one of them a new hire - which is an actionable list.
HIGH_FRICTION_THRESHOLD = 40.0
MEDIUM_FRICTION_THRESHOLD = 25.0

# Saturation points for the friction score components. A hire who has raised
# TICKET_SATURATION tickets, or waited RESOLUTION_SATURATION_HOURS on average,
# scores the full weight for that component.
TICKET_SATURATION = 5.0
RESOLUTION_SATURATION_HOURS = 48.0

# Component weights. They sum to 1.0, which is what bounds the score to 0-100
# without the clipping that used to hide the real spread.
W_TRAINING_GAP = 0.5
W_TICKET_LOAD = 0.3
W_RESOLUTION_DRAG = 0.2

# "First month" cohort: recent hires plus anyone still mid-onboarding.
NEW_HIRE_MAX_YEARS = 1
IN_FLIGHT_STATUSES = ("In Progress", "Delayed")


@lru_cache(maxsize=1)
def get_ml_predictions() -> pd.DataFrame:
    """Score every employee with the trained model.

    Returns an empty frame (and logs the reason) when the model or its feature
    table is unavailable, so the dashboard degrades to the rule-based friction
    score instead of silently reporting a 0% risk for everyone.
    """
    empty = pd.DataFrame(columns=["employee_id", "predicted_risk"])
    if not MODEL_PATH.exists() or not ENGINEERED_DATA_PATH.exists():
        logger.warning(
            "ML artefacts missing (%s / %s). Run the notebooks in 'ML model/' "
            "to regenerate them. Serving rule-based scores only.",
            MODEL_PATH.name,
            ENGINEERED_DATA_PATH.name,
        )
        return empty
    try:
        with open(MODEL_PATH, "rb") as handle:
            model = pickle.load(handle)
        features = pd.read_csv(ENGINEERED_DATA_PATH)
        X = features.drop(columns=["employee_id", "high_friction"])
        scored = pd.DataFrame(
            {
                "employee_id": features["employee_id"],
                "predicted_risk": model.predict_proba(X)[:, 1] * 100,
            }
        )
        return scored
    except Exception:
        logger.exception(
            "Could not load or apply %s. Install the pinned ML dependencies "
            "(see backend/requirements.txt) and re-run the scoring notebook.",
            MODEL_PATH.name,
        )
        return empty


def ml_model_available() -> bool:
    return not get_ml_predictions().empty


def compute_friction_score(frame: pd.DataFrame) -> pd.Series:
    """Composite 0-100 operational friction score.

    Blends three normalised signals so no single unbounded input (previously
    average resolution hours) can dominate and pin everyone to 100:

    * how much required training is still outstanding
    * how many support tickets the hire has had to raise
    * how long those tickets take to resolve
    """
    training_gap = (100.0 - frame["training_completion_percent"]).clip(0, 100)
    ticket_load = (frame["ticket_count"] / TICKET_SATURATION).clip(0, 1) * 100
    resolution_drag = (
        frame["avg_resolution"] / RESOLUTION_SATURATION_HOURS
    ).clip(0, 1) * 100

    score = (
        W_TRAINING_GAP * training_gap
        + W_TICKET_LOAD * ticket_load
        + W_RESOLUTION_DRAG * resolution_drag
    )
    return score.round(1)


def build_employee_friction_table() -> pd.DataFrame:
    """Join HR, onboarding, ticket and ML data into one ranked table."""
    df_emp = fetch_table_as_df("employees")
    df_onb = fetch_table_as_df("onboarding")
    df_tickets = fetch_table_as_df("support_tickets")

    ticket_stats = (
        df_tickets.groupby("employee_id")
        .agg(
            ticket_count=("ticket_id", "count"),
            avg_resolution=("resolution_hours", "mean"),
        )
        .reset_index()
    )

    merged = pd.merge(
        df_emp[["employee_id", "JobRole", "Department", "YearsAtCompany"]],
        df_onb[
            [
                "employee_id",
                "onboarding_status",
                "training_completion_percent",
            ]
        ],
        on="employee_id",
        how="inner",
    )
    merged = pd.merge(merged, ticket_stats, on="employee_id", how="left")

    # Only the numeric ticket columns are meaningfully zero-filled. Blanket
    # .fillna(0) used to coerce missing categorical values to the integer 0.
    merged["ticket_count"] = merged["ticket_count"].fillna(0)
    # No tickets means no waiting, not a zero-hour wait on an imaginary ticket.
    merged["avg_resolution"] = merged["avg_resolution"].fillna(0.0)

    merged = pd.merge(
        merged, get_ml_predictions(), on="employee_id", how="left"
    )
    merged["predicted_risk"] = merged["predicted_risk"].round(1)

    merged["friction_score"] = compute_friction_score(merged)
    merged["friction_band"] = pd.cut(
        merged["friction_score"],
        bins=[-0.01, MEDIUM_FRICTION_THRESHOLD, HIGH_FRICTION_THRESHOLD, 100.0],
        labels=["Low", "Medium", "High"],
    ).astype(str)
    return merged.sort_values(by="friction_score", ascending=False)


def is_new_hire(frame: pd.DataFrame) -> pd.Series:
    return (frame["YearsAtCompany"] <= NEW_HIRE_MAX_YEARS) | frame[
        "onboarding_status"
    ].isin(IN_FLIGHT_STATUSES)


class DashboardKPIsView(APIView):
    """Headline onboarding metrics for the first-month cohort."""

    def get(self, request):
        df_emp = fetch_table_as_df("employees")
        df_onb = fetch_table_as_df("onboarding")
        df_tickets = fetch_table_as_df("support_tickets")

        cohort = pd.merge(
            df_emp[["employee_id", "YearsAtCompany"]],
            df_onb[["employee_id", "onboarding_days", "onboarding_status"]],
            on="employee_id",
            how="inner",
        )
        # The KPI row is labelled "per hire", so scope it to actual new hires
        # rather than to the entire 1,470-person company.
        new_hires = cohort[is_new_hire(cohort)]
        if new_hires.empty:
            return Response(
                {
                    "detail": "No employees match the new-hire cohort "
                    "definition; check the onboarding dataset."
                },
                status=status.HTTP_404_NOT_FOUND,
            )

        avg_onboarding_days = float(new_hires["onboarding_days"].mean())
        new_hire_ids = new_hires["employee_id"].unique()
        new_hire_tickets = df_tickets[
            df_tickets["employee_id"].isin(new_hire_ids)
        ]
        avg_tickets = len(new_hire_tickets) / len(new_hire_ids)

        # Time-to-value = onboarding duration plus a fixed ramp-up allowance.
        # The allowance is an explicit business assumption, not a measurement.
        RAMP_UP_DAYS = 7
        time_to_value = avg_onboarding_days + RAMP_UP_DAYS

        return Response(
            {
                "avg_onboarding_days": round(avg_onboarding_days, 1),
                "time_to_value": round(time_to_value, 1),
                "avg_tickets": round(avg_tickets, 1),
                "new_hire_count": int(len(new_hire_ids)),
            }
        )


class FrictionChartsView(APIView):
    """Aggregated series for the four dashboard charts."""

    def get(self, request):
        df_onb = fetch_table_as_df("onboarding")
        df_tickets = fetch_table_as_df("support_tickets")
        df_tools = fetch_table_as_df("tool_usage")

        # 1. Training completion vs. ticket volume
        ticket_counts = (
            df_tickets.groupby("employee_id").size().reset_index(name="ticket_count")
        )
        scatter = pd.merge(
            df_onb[["employee_id", "training_completion_percent"]],
            ticket_counts,
            on="employee_id",
            how="left",
        )
        scatter["ticket_count"] = scatter["ticket_count"].fillna(0).astype(int)

        # 2. Most common blockers
        blockers = df_tickets["issue_type"].value_counts().reset_index()
        blockers.columns = ["issue_type", "count"]

        # 3. Tool adoption over time (chronological, so the line chart reads
        #    left to right instead of in lexicographic date order)
        df_tools = df_tools.copy()
        df_tools["date"] = pd.to_datetime(df_tools["date"], errors="coerce")
        df_tools["active_minutes"] = pd.to_numeric(
            df_tools["active_minutes"], errors="coerce"
        )
        df_tools = df_tools.dropna(subset=["date", "active_minutes"])
        tool_adoption = (
            df_tools.groupby(["date", "tool_name"])["active_minutes"]
            .mean()
            .unstack("tool_name")
            .sort_index()
            .round(1)
            .fillna(0)
            .reset_index()
        )
        tool_adoption["date"] = tool_adoption["date"].dt.strftime("%Y-%m-%d")

        # 4. Buddy programme impact, with the sample size behind each bar
        buddy = df_onb.copy()
        buddy["has_buddy"] = yes_no_to_bool(buddy["buddy_assigned"])
        buddy_impact = (
            buddy.groupby("has_buddy")
            .agg(
                training_completion_percent=(
                    "training_completion_percent",
                    "mean",
                ),
                employee_count=("employee_id", "count"),
            )
            .reset_index()
            .rename(columns={"has_buddy": "buddy_assigned"})
        )
        buddy_impact["training_completion_percent"] = buddy_impact[
            "training_completion_percent"
        ].round(1)

        return Response(
            {
                "scatter": scatter.to_dict("records"),
                "blockers": blockers.to_dict("records"),
                "tool_adoption": tool_adoption.to_dict("records"),
                "buddy_impact": buddy_impact.to_dict("records"),
            }
        )


class EmployeeFrictionTableView(APIView):
    """Ranked employee friction list.

    Supports ``?limit=`` (default 100, max 1000) and ``?department=``. The
    high-risk count is computed over the whole dataset, not just the page
    returned, so the dashboard banner cannot under-report.
    """

    DEFAULT_LIMIT = 100
    MAX_LIMIT = 1000

    def get(self, request):
        table = build_employee_friction_table()

        department = request.query_params.get("department")
        if department and department.lower() != "all":
            table = table[table["Department"] == department]

        try:
            limit = int(request.query_params.get("limit", self.DEFAULT_LIMIT))
        except ValueError:
            return Response(
                {"detail": "'limit' must be an integer."},
                status=status.HTTP_400_BAD_REQUEST,
            )
        limit = max(1, min(limit, self.MAX_LIMIT))

        total_high_risk = int(
            (table["friction_score"] > HIGH_FRICTION_THRESHOLD).sum()
        )
        page = table.head(limit).drop(columns=["YearsAtCompany"])

        return Response(
            {
                "total_high_risk": total_high_risk,
                "high_friction_threshold": HIGH_FRICTION_THRESHOLD,
                "medium_friction_threshold": MEDIUM_FRICTION_THRESHOLD,
                "ml_model_available": ml_model_available(),
                "results": page.where(pd.notnull(page), None).to_dict("records"),
            }
        )
