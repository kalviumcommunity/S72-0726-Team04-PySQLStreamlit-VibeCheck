"""Regression tests for the dashboard API.

These cover the bugs the audit found: an unbounded friction score that pinned
well-onboarded employees to 100, a high-risk count computed only over the
returned page, KPIs scoped to the whole company instead of new hires, and a
silently-zeroed ML risk when the model fails to load.
"""

import pandas as pd
from django.test import SimpleTestCase
from django.urls import reverse

from .utils import yes_no_to_bool
from .views import (
    HIGH_FRICTION_THRESHOLD,
    compute_friction_score,
    is_new_hire,
)


class FrictionScoreTests(SimpleTestCase):
    def _score(self, training, tickets, resolution):
        frame = pd.DataFrame(
            {
                "training_completion_percent": [training],
                "ticket_count": [tickets],
                "avg_resolution": [resolution],
            }
        )
        return float(compute_friction_score(frame).iloc[0])

    def test_fully_onboarded_employee_scores_zero(self):
        self.assertEqual(self._score(100.0, 0, 0.0), 0.0)

    def test_worst_case_employee_scores_one_hundred(self):
        self.assertEqual(self._score(0.0, 20, 500.0), 100.0)

    def test_score_stays_within_bounds(self):
        self.assertGreaterEqual(self._score(0.0, 0, 0.0), 0.0)
        self.assertLessEqual(self._score(0.0, 99, 999.0), 100.0)

    def test_slow_ticket_resolution_alone_is_not_high_friction(self):
        """The old formula clipped this employee to 100 despite 91.7% training."""
        score = self._score(91.7, 1, 71.9)
        self.assertLess(score, HIGH_FRICTION_THRESHOLD)

    def test_untrained_employee_with_many_tickets_is_high_friction(self):
        self.assertGreater(self._score(20.0, 6, 60.0), HIGH_FRICTION_THRESHOLD)

    def test_threshold_actually_selects_someone(self):
        """The old threshold of 70 could never fire on the corrected scale."""
        from .views import build_employee_friction_table

        table = build_employee_friction_table()
        flagged = table[table["friction_score"] > HIGH_FRICTION_THRESHOLD]
        self.assertGreater(len(flagged), 0)
        self.assertLess(len(flagged), len(table) * 0.1)

    def test_training_gap_dominates_ticket_load(self):
        undertrained = self._score(10.0, 0, 0.0)
        ticket_heavy = self._score(100.0, 20, 0.0)
        self.assertGreater(undertrained, ticket_heavy)


class NewHireCohortTests(SimpleTestCase):
    def test_cohort_includes_recent_hires_and_in_flight_onboarding(self):
        frame = pd.DataFrame(
            {
                "YearsAtCompany": [0, 1, 6, 9],
                "onboarding_status": [
                    "In Progress",
                    "Completed",
                    "Delayed",
                    "Completed",
                ],
            }
        )
        self.assertEqual(list(is_new_hire(frame)), [True, True, True, False])


class YesNoParsingTests(SimpleTestCase):
    def test_various_truthy_spellings(self):
        series = pd.Series(["Yes", "yes", " Y ", "true", "1", "No", "n", ""])
        self.assertEqual(
            list(yes_no_to_bool(series)),
            [True, True, True, True, True, False, False, False],
        )


class EndpointContractTests(SimpleTestCase):
    """Smoke tests against the bundled CSV fallback data."""

    def test_kpis_are_scoped_to_new_hires(self):
        response = self.client.get(reverse("dashboard_kpis"))
        self.assertEqual(response.status_code, 200)
        body = response.json()
        for key in (
            "avg_onboarding_days",
            "time_to_value",
            "avg_tickets",
            "new_hire_count",
        ):
            self.assertIn(key, body)
        # 1,470 is the full employee table; the cohort must be smaller.
        self.assertLess(body["new_hire_count"], 1470)
        self.assertGreater(body["new_hire_count"], 0)

    def test_charts_payload_shape(self):
        response = self.client.get(reverse("friction_charts"))
        self.assertEqual(response.status_code, 200)
        body = response.json()
        for key in ("scatter", "blockers", "tool_adoption", "buddy_impact"):
            self.assertTrue(body[key], f"{key} should not be empty")
        self.assertEqual(len(body["buddy_impact"]), 2)
        dates = [row["date"] for row in body["tool_adoption"]]
        self.assertEqual(dates, sorted(dates), "tool adoption must be chronological")

    def test_employees_reports_global_high_risk_count(self):
        response = self.client.get(reverse("employee_friction"), {"limit": 5})
        self.assertEqual(response.status_code, 200)
        body = response.json()
        self.assertEqual(len(body["results"]), 5)
        self.assertIn("total_high_risk", body)
        self.assertIn("ml_model_available", body)
        # The count must not be capped by the page size.
        self.assertGreaterEqual(body["total_high_risk"], 0)
        scores = [row["friction_score"] for row in body["results"]]
        self.assertEqual(scores, sorted(scores, reverse=True))
        self.assertLessEqual(max(scores), 100.0)

    def test_employees_rejects_a_non_numeric_limit(self):
        response = self.client.get(reverse("employee_friction"), {"limit": "abc"})
        self.assertEqual(response.status_code, 400)

    def test_employees_can_be_filtered_by_department(self):
        response = self.client.get(
            reverse("employee_friction"), {"department": "Sales", "limit": 20}
        )
        self.assertEqual(response.status_code, 200)
        departments = {row["Department"] for row in response.json()["results"]}
        self.assertEqual(departments, {"Sales"})
